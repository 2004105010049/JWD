<?php
include'../koneksi.php';
$id=$_GET['id'];

mysqli_query($db,
	"DELETE FROM tartikel
	WHERE id='$id'"
);
header("location:../index.php?p=artikel");
?>