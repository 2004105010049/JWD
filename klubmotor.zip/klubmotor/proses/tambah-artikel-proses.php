<?php
// Koneksi ke database
include'../koneksi.php';

// Ambil data artikel dari form atau variabel
$title = $_POST['title'];
$description = $_POST['description'];
$image_name = $_FILES['image']['name'];
$image_data = addslashes(file_get_contents($_FILES['image']['tmp_name']));
$article_link = $_POST['article_link'];

// Query untuk menyimpan data artikel ke database
$sql = "INSERT INTO tartikel (title, description, image_name, image_data, article_link) 
        VALUES ('$title', '$description', '$image_name', '$image_data', '$article_link')";

if (mysqli_query($db, $sql)) {
    echo "Data artikel berhasil diunggah.";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);


}
header("location:../index.php?p=artikel");
?>
