<?php
	$id_artikel=$_GET['id'];
	$q_tampil_artikel=mysqli_query($db,"SELECT * FROM tartikel WHERE id='$id_artikel'");
	$r_tampil_artikel=mysqli_fetch_array($q_tampil_artikel);
?>
<div id="label-page"><h3>Edit Data Artikel</h3></div>
<div id="content">
<form action="proses/artikel-edit-proses.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <label for="title">Judul Artikel:</label><br>
        <input type="text" id="title" name="title" value="<?php echo $row['title']; ?>"><br><br>
        
        <label for="description">Deskripsi Artikel:</label><br>
        <textarea id="description" name="description" rows="4" cols="50"><?php echo $row['description']; ?></textarea><br><br>
        
        <label for="image">Gambar Artikel:</label><br>
        <input type="file" id="image" name="image" accept="image/*"><br><br>
        
        <label for="article_link">Link Artikel:</label><br>
        <input type="text" id="article_link" name="article_link" value="<?php echo $row['article_link']; ?>"><br><br>
        
        <input type="submit" value="Update">
    </form>
</div>