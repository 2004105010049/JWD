<div id="label-page"><h3>Home</h3></div>
<div id="content">
	<div id="beranda-judul">
		<h1>SELAMAT DATANG DI WEBSITE PELE MILES MOTORCYCLE CLUB</h1>
	</div>
</div>