<section id="achievements">
                    <h2>Prestasi</h2>
                    <p>Pele Miles Motorcycle Club telah berhasil dalam berbagai kejuaraan dan pameran bergengsi di Indonesia. Beberapa di antaranya termasuk:</p>
                    <ul>
                        <li>Kejuaraan Balap Motor Nasional</li>
                        <li>Pameran Jakarta Fair Auto Show</li>
                        <li>Pameran Motor Klasik Nasional</li>
                        <!-- Prestasi lainnya dapat ditambahkan di sini -->
                    </ul>
                </section>