<div class="container">
                    <h1 class="text-center my-5">Produk Kami</h1>
                    <div class="row">
                        <div class="col-md-4 mb-4">
                            <div class="card">
                                <img src="image/merchandise.jpg" class="card-img-top" alt="Merchandise">
                                <div class="card-body">
                                    <h5 class="card-title">Merchandise</h5>
                                    <p class="card-text">Kaos, topi, jaket, dan aksesori lainnya dengan logo klub motor.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="card">
                                <img src="image/sticker.jpg" class="card-img-top" alt="Sticker">
                                <div class="card-body">
                                    <h5 class="card-title">Stiker dan Patches</h5>
                                    <p class="card-text">Stiker dan lencana klub motor untuk ditempel di helm, motor, atau pakaian.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="card">
                                <img src="image/riding-gear.jpg" class="card-img-top" alt="Riding Gear">
                                <div class="card-body">
                                    <h5 class="card-title">Perlengkapan Riding</h5>
                                    <p class="card-text">Sarung tangan, pelindung lutut, dan perlengkapan keselamatan lainnya.</p>
                                </div>
                            </div>
                        </div>
                        <!-- Tambahkan item lainnya di sini -->
                    </div>
                </div>