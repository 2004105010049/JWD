<?php
	$id_artikel=$_GET['id'];
	$q_tampil_artikel=mysqli_query($db,"SELECT * FROM timage WHERE id='$id_artikel'");
	$r_tampil_artikel=mysqli_fetch_array($q_tampil_artikel);
?>
<div id="label-page"><h3>Edit Data Gambar</h3></div>
<div id="content">
<form action="proses/edit-gambar-proses.php" method="post" enctype="multipart/form-data">
        
        <label for="image">Gambar Artikel:</label><br>
        <input type="file" id="image" name="image" accept="image/*"><br><br>
        
        
        <input type="submit" value="Update">
    </form>
</div>