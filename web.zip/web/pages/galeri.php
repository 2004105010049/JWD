<?php
$server = "localhost";
$user = "root";
$password = "";
$nama_database = "dbmotor";

$db = mysqli_connect($server, $user, $password, $nama_database);

if( !$db ){
    die("Gagal terhubung dengan database: " . mysqli_connect_error());
}
$tgl=date('Y-m-d');

// Query SQL untuk mengambil data artikel
$sql = "SELECT * FROM timage";
$result = mysqli_query($db, $sql);

// Periksa apakah query berhasil dijalankan
if (!$result) {
    die("Error: " . mysqli_error($db));
}

// Periksa apakah ada data yang ditemukan
if (mysqli_num_rows($result) > 0)
?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="container mt-5">
                <h2 class="mb-4">Daftar Artikel</h2>
                <div class="row row-cols-1 row-cols-md-3 g-4">
                    <?php
                    // Tampilkan data artikel
                    while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="col">
                        <div class="card">
                            <img src="<?php echo $row['image_name']; ?>" class="card-img-top" alt="<?php echo $row['title']; ?>" style="height: 200px;">
                            </div>
                        </div>
                    </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </main>