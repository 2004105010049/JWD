<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <!-- Konten dari setiap halaman akan dimasukkan di sini -->
                <!-- Contoh konten halaman home -->
                    <h2>Tentang Kami</h2>
                    <p>Muhammad Fauzan mendirikan Pele Miles Motorcycle Club pada tahun 1995 di Jalan Kemerdekaan, Indonesia. Klub ini awalnya terdiri dari sekelompok pecinta motor yang berbagi minat dalam kustomisasi motor dan petualangan. Mereka berkumpul secara teratur di sebuah garasi kecil untuk berbagi pengetahuan dan pengalaman. Seiring waktu, klub ini berkembang menjadi pusat komunitas motor yang aktif di wilayahnya. Mereka terlibat dalam kegiatan sosial dan amal serta menyelenggarakan acara tahunan seperti "Pele Miles Motorfest", menarik ribuan penggemar motor dari seluruh Indonesia. Klub ini tetap menjadi inspirasi bagi generasi berikutnya dari penggemar motor di Indonesia.</p>
            </main>