<div class="container mt-5">
                    <h2 class="mb-4">Anggota Klub</h2>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Daerah</th>
                                <th scope="col">Jumlah Anggota</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Jawa Barat</td>
                                <td>40</td>
                            </tr>
                            <tr>
                                <td>Jawa Timur</td>
                                <td>35</td>
                            </tr>
                            <tr>
                                <td>DKI Jakarta</td>
                                <td>25</td>
                            </tr>
                            <tr>
                                <td>Jawa Tengah</td>
                                <td>20</td>
                            </tr>
                            <tr>
                                <td>Sumatera Utara</td>
                                <td>10</td>
                            </tr>
                            <!-- Tambahkan daerah-daerah lainnya sesuai kebutuhan -->
                        </tbody>
                        <tfoot>
                            <tr>
                                <td><strong>Total</strong></td>
                                <td><strong>143</strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>