<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <h2>Visi</h2>
                <p>Menjadi klub motor terkemuka di Indonesia yang mempromosikan keselamatan berkendara dan semangat persaudaraan di antara para penggemar motor.</p>

                <h2>Misi</h2>
                <ul>
                    <li>Meningkatkan kesadaran akan pentingnya keselamatan berkendara.</li>
                    <li>Mengadakan kegiatan sosial dan kegiatan amal untuk membantu masyarakat.</li>
                    <li>Mengadakan acara dan kompetisi yang mempererat hubungan antara anggota klub.</li>
                    <li>Menyediakan platform untuk berbagi informasi dan pengalaman tentang motor.</li>
                </ul>
            </main>