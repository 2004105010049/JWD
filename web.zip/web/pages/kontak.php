<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <!-- Konten dari setiap halaman akan dimasukkan di sini -->
                <!-- Contoh konten halaman home -->
                    <h2>Kontak Kami</h2>
                    <p>Jl. Kemerdekaan No 17</p>
                    <p>Telp : (081)71945555</p>
                    <p>Email: pmmc95@gmail.com</p>
            </main>