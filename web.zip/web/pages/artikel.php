<?php
$server = "localhost";
$user = "root";
$password = "";
$nama_database = "dbmotor";

$db = mysqli_connect($server, $user, $password, $nama_database);

if( !$db ){
    die("Gagal terhubung dengan database: " . mysqli_connect_error());
}
$tgl=date('Y-m-d');

// Query SQL untuk mengambil data artikel
$sql = "SELECT * FROM tartikel";
$result = mysqli_query($db, $sql);

// Periksa apakah query berhasil dijalankan
if (!$result) {
    die("Error: " . mysqli_error($db));
}

// Periksa apakah ada data yang ditemukan
if (mysqli_num_rows($result) > 0)
?>
    <div class="row">
    <?php
    // Query untuk mengambil data artikel
    $sql = "SELECT * FROM tartikel";
    $result = mysqli_query($db, $sql);

    // Menampilkan data artikel dalam kartu
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<div class="col-md-4 mb-4">';
            echo '<div class="card">';
            echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image_data']) . '" class="card-img-top" alt="Gambar Artikel">';
            echo '<div class="card-body">';
            echo '<h5 class="card-title">' . $row['title'] . '</h5>';
            echo '<p class="card-text">' . $row['description'] . '</p>';
            echo '<a href="' . $row['article_link'] . '" class="btn btn-primary" target="_blank">Baca Artikel</a>';
            echo '</div>';
            echo '<div class="card-footer">';
            echo '<small class="text-muted">No: ' . $row['id'] . '</small>';

            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
    } else {
        echo "<p class='col'>Tidak ada artikel.</p>";
    }
    ?>
</div>
