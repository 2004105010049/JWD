<div id="label-page"><h3>Tampil Data Artikel</h3></div>
<div id="content">
	<p id="tombol-tambah-container"><a href="index.php?p=tambah-artikel" class="tombol">Tambah Artikel</a></p>
	<table id="tabel-tampil">
		<tr>
			<th id="label-tampil-no">No</td>
			<th>Judul</th>
			<th>Deskripsi</th>
			<th>Gambar</th>
			<th>Link</th>
			<th id="label-opsi">Opsi</th>
		</tr>
		
		
		<?php
		// Query untuk mengambil data artikel
        $sql = "SELECT * FROM tartikel";
        $result = mysqli_query($db, $sql);

        // Menampilkan data artikel dalam tabel
        if (mysqli_num_rows($result) > 0) {
            $no = 1; 
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $no++ . "</td>";
                echo "<td>" . $row['title'] . "</td>";
                echo "<td>" . $row['description'] . "</td>";
                echo "<td><img src='data:image/jpeg;base64," . base64_encode($row['image_data']) . "' height='100'></td>";
                echo "<td><a href='" . $row['article_link'] . "' target='_blank'>Link</a></td>";
                echo '<td>
                    <div class="tombol-opsi-container"><a href="index.php?p=edit-artikel&id='.$row['id'].'" class="tombol">Edit</a></div>
                    <div class="tombol-opsi-container"><a href="proses/hapus-artikel-proses.php?id='.$row['id'].'" class="tombol">Hapus</a></div>
                    </td>';
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>Tidak ada artikel.</td></tr>";
        }

		?>
	</table>
</div>