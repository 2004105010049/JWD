<div id="label-page"><h3>Tampil Data Gambar</h3></div>
<div id="content">
	<p id="tombol-tambah-container"><a href="index.php?p=tambah-foto" class="tombol">Tambah </a></p>
	<table id="tabel-tampil">
		<tr>
			<th id="label-tampil-no">No</td>
			<th>Foto</th>
			<th id="label-opsi">Opsi</th>
		</tr>
		
		
		<?php
		// Query untuk mengambil data 
        $sql = "SELECT * FROM timage";
        $result = mysqli_query($db, $sql);

        // Menampilkan data  dalam tabel
        if (mysqli_num_rows($result) > 0) {
            $no = 1; 
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                
                echo "<td><img src='data:image/jpeg;base64," . base64_encode($row['image_data']) . "' height='100'></td>";
                echo '<td>
                    <div class="tombol-opsi-container"><a href="index.php?p=edit-foto&id='.$row['id'].'" class="tombol">Edit</a></div>
                    <div class="tombol-opsi-container"><a href="proses/hapus-foto-proses.php?id='.$row['id'].'" class="tombol">Hapus</a></div>
                    </td>';
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>Tidak ada .</td></tr>";
        }

		?>
	</table>
</div>