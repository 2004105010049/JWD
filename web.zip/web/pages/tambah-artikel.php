<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Artikel</title>
</head>
<body>
    <h2>Input Artikel</h2>
    <form action="proses/tambah-artikel-proses.php" method="post" enctype="multipart/form-data">
        <label for="title">Judul Artikel:</label><br>
        <input type="text" id="title" name="title" required><br><br>
        
        <label for="description">Deskripsi Artikel:</label><br>
        <textarea id="description" name="description" rows="4" cols="50" required></textarea><br><br>
        
        <label for="image">Gambar Artikel:</label><br>
        <input type="file" id="image" name="image" accept="image/*" required><br><br>
        
        <label for="article_link">Link Artikel:</label><br>
        <input type="text" id="article_link" name="article_link" required><br><br>
        
        <input type="submit" value="Submit">
    </form>
</body>
</html>
