<?php
// Koneksi ke database
include'../koneksi.php';

// Ambil data dari form
$username = $_POST['username'];
$password = $_POST['password'];

// Lindungi dari serangan SQL Injection
$username = mysqli_real_escape_string($db, $username);
$password = mysqli_real_escape_string($db, $password);

// Query untuk memeriksa apakah username dan password cocok
$sql = "SELECT * FROM tadmin WHERE username='$username' AND password='$password'";
$result = mysqli_query($db, $sql);

// Periksa apakah ada hasil dari query
if (mysqli_num_rows($result) > 0) {
    // Login berhasil
    echo "Login berhasil!";
    header("location:../index.php?p=beranda");

} else {
    // Login gagal
    echo "Username atau password salah!";
}

?>
