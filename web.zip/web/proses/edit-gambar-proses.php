<?php
// Koneksi ke database
include'../koneksi.php';

// Ambil data artikel dari form atau variabel

$image_data = addslashes(file_get_contents($_FILES['image']['tmp_name']));


// Query untuk menyimpan data artikel ke database
$sql = "UPDATE timage 
        SET 
            
            image_data = '$image_data'
           
        WHERE id = $id";

if (mysqli_query($db, $sql)) {
    echo "Data artikel berhasil diunggah.";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);


}
header("location:../index.php?p=articel");
?>
