<?php
// Koneksi ke database
include'../koneksi.php';

// Ambil data dari form atau variabel
$image_data = addslashes(file_get_contents($_FILES['image']['tmp_name']));

// Query untuk menyimpan data artikel ke database
$sql = "INSERT INTO timage (image_data) 
        VALUES ( '$image_data')";

if (mysqli_query($db, $sql)) {
    echo "Data foto berhasil diunggah.";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);


}
header("location:../index.php?p=foto");
?>
