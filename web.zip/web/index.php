<?php
include'koneksi.php';
$tgl=date('Y-m-d');
?>
<!doctype html>
<html>
<head>
	<title>Pele Miles Website</title>
	
	 <!-- Bootstrap CSS -->
     <link rel="stylesheet" type="text/css" href="style.css">
	 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"><link rel="stylesheet" type="text/css" href="style.css">
</head>
<body >
	<div id="container">
		<div id="header">
		<div class="row">
            <div class="col ml-3">
                <image id="logo-perpustakaan" src="images/logo-klub.png" border=0 style="border:0; text-decoration:none; outline:none"> 
            </div>
            <div class="col-6 d-flex justify-content-center align-items-center">
                <h1 class="text-center">PELE MILES MOTORCYCLE CLUB</h1>
            </div>
            <div class="col btn btn-warning justify-content-center align-items-center">
                <p id="tombol-tambah-container"><a href="dashboard.php" class="tombol">Logout</a></p>
            </div>
        </div>
		</div>
		<div id="header2">
			<div id="nama-user">Hai Bro !</div>
		</div>
		<div id="sidebar">
			<a href="index.php?p=beranda">Home</a>
			<ul>
				<li><a href="index.php?p=foto">Foto</a></li>
				<li><a href="index.php?p=articel">Artikel</a></li>
			</ul>
		</div>
		<div id="content-container">
			    <div class="container">
		<div class="row"><br/><br/><br/>
			<div class="col-md-10 col-md-offset-1" style="background-image:url('../asanoer-background.jpg')">
				<div class="col-md-4 col-md-offset-4">
					<div class="panel panel-warning login-panel" style="background-color:rgba(255, 255, 255, 0.6);position:relative;">
						<div class="panel-footer">
						</div>
					</div>
				</div>
			</div>
		</div>
</div>
<?php
			$pages_dir='pages';
			if(!empty($_GET['p'])){
				$pages=scandir($pages_dir,0);
				unset($pages[0],$pages[1]);
				$p=$_GET['p'];
				if(in_array($p.'.php',$pages)){
					include($pages_dir.'/'.$p.'.php');
				}else{
					echo'Halaman Tidak Ditemukan';
				}
			}else{
				include($pages_dir.'/home.php');
			}
		?>
		</div>
		<footer class="footer fixed-bottom mt-auto py-3 bg-light">
        <div class="container text-center">
          <span class="text-muted">© 2024 PELE MILES MOTORCYCLE CLUB</span>
        </div>
    </footer>
	</div>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

</body>
</html>